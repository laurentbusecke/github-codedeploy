#!/bin/bash

#/etc/init.d/httpd stop
sudo systemctl stop httpd
